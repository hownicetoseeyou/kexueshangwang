$(function(){
// IPad/IPhone
	var viewportmeta = document.querySelector && document.querySelector('meta[name="viewport"]'),
    ua = navigator.userAgent,
 
    gestureStart = function () {
        viewportmeta.content = "width=device-width, minimum-scale=0.25, maximum-scale=1.6";
    },
 
    scaleFix = function () {
      if (viewportmeta && /iPhone|iPad/.test(ua) && !/Opera Mini/.test(ua)) {
        viewportmeta.content = "width=device-width, minimum-scale=1.0, maximum-scale=1.0";
        document.addEventListener("gesturestart", gestureStart, false);
      }
    };
scaleFix();
// Menu Android
	var userag = navigator.userAgent.toLowerCase();
	var isAndroid = userag.indexOf("android") > -1; 
	if(isAndroid) {
		$('.sf-menu').responsiveMenu({autoArrows:true});
	}
// Slider
	$('#slides').slides({
		effect: 'fade',
		fadeSpeed:700,
		preload: false,
		play: 4000,
		pause: 4000,
		crossfade: true,
		hoverPause: true,
		animationStart: function(current){
		$('.caption').animate({
			opacity:0
			},100);
			if (window.console && console.log) {
			console.log('animationStart on slide: ', current);
			};
		},
		animationComplete: function(current){
		$('.caption').animate({
			opacity:1
			},200);
			if (window.console && console.log) {
			console.log('animationComplete on slide: ', current);
			};
		},
		slidesLoaded: function() {
			$('.caption').animate({
			opacity:1
			},200);
		}  
	});
	$('#slides_two').slides({
		effect: 'fade',
		container:"slides_container2",
		fadeSpeed:700,
		preload: false,
		crossfade: true,
		hoverPause: true
	});
	$('#slides_three').slides({
		effect: 'slide',
		container:"slides_container3",
		preload: false,
		generateNextPrev: true,
		generatePagination: false,
		hoverPause: true
	});
	$('.next,.prev').hover(function(){$(this).stop().animate({opacity:.5})},(function(){$(this).stop().animate({opacity:1})}))
// Social Icons
	$('.tooltips li a').append('<span></span>').each(
	function(){
	var src=new Array()
	src=$(this).find('>img').attr('src').split('.')
	src=src[0]+'-hover.'+src[1]
	$(this).find('>span').css({background:'url('+src+')'})
 });
});
